import 'package:flutter/material.dart';
import '../theme.dart';

class Feature {
  final String id;
  final String icon;
  final String label;
  final Color bg;
  final String tag;
  final String note;

  const Feature({
    required this.id,
    required this.icon,
    required this.label,
    required this.bg,
    required this.tag,
    required this.note,
  });
}

/// झटपट के सभी 11 फीचर्स — होम ग्रिड और नेविगेशन दोनों यहीं से चलते हैं।
const List<Feature> kFeatures = [
  Feature(id: 'home', icon: '🏠', label: 'होम', bg: Color(0xFFFFE8B8), tag: 'नेविगेशन', note: 'यह आपकी होम स्क्रीन है — स्टोरीज़, कमाई बैनर और सभी फीचर्स का ग्रिड यहीं से शुरू होता है।'),
  Feature(id: 'video', icon: '🎬', label: 'वीडियो + एडिटिंग', bg: Color(0xFFFFD5DA), tag: 'कंटेंट', note: 'शॉर्ट वीडियो देखें, रिकॉर्ड करें और बिल्ट-इन एडिटर से ट्रिम, फिल्टर, टेक्स्ट व म्यूज़िक जोड़ें।'),
  Feature(id: 'call', icon: '📞', label: 'ऑडियो/वीडियो कॉलिंग', bg: Color(0xFFD7F5EF), tag: 'कम्युनिकेशन', note: 'HD ऑडियो और वीडियो कॉल — 1-टू-1 या ग्रुप में, सीधे कॉन्टैक्ट लिस्ट से शुरू करें।'),
  Feature(id: 'chat', icon: '💬', label: 'चैटिंग', bg: Color(0xFFE3DBFF), tag: 'कम्युनिकेशन', note: 'टेक्स्ट, वॉइस नोट्स, फोटो-वीडियो शेयरिंग के साथ रियल-टाइम मैसेजिंग।'),
  Feature(id: 'contacts', icon: '👥', label: 'कॉन्टैक्ट्स', bg: Color(0xFFFFE3C7), tag: 'नेटवर्क', note: 'अपने सभी दोस्तों और परिवार की लिस्ट, सिंक और नए लोगों को खोजें।'),
  Feature(id: 'social', icon: '❤️', label: 'लाइक/कमेंट/शेयर', bg: Color(0xFFFFDCE1), tag: 'सोशल', note: 'पोस्ट्स और रील्स पर लाइक, कमेंट करें और दोस्तों के साथ शेयर करें।'),
  Feature(id: 'shop', icon: '🛍️', label: 'शॉप', bg: Color(0xFFD8F0FF), tag: 'कॉमर्स', note: 'प्रोडक्ट्स ब्राउज़ करें, कार्ट में जोड़ें और सीधे ऐप के अंदर से ऑर्डर करें।'),
  Feature(id: 'earnings', icon: '💰', label: 'कमाई', bg: Color(0xFFD9F7DD), tag: 'मॉनेटाइज़ेशन', note: 'रील्स, शॉप सेल्स और रेफरल से हुई कमाई का पूरा हिसाब यहां दिखेगा।'),
  Feature(id: 'studio', icon: '📸', label: 'फोटो/वीडियो स्टूडियो', bg: Color(0xFFFFEAD1), tag: 'क्रिएशन', note: 'फिल्टर, स्टिकर, टेक्स्ट और ट्रांज़िशन के साथ प्रोफेशनल-लेवल फोटो-वीडियो बनाएं।'),
  Feature(id: 'profile', icon: '👤', label: 'प्रोफाइल', bg: Color(0xFFE7E1FF), tag: 'अकाउंट', note: 'अपनी जानकारी, पोस्ट्स, फॉलोअर्स और सेटिंग्स यहां मैनेज करें।'),
  Feature(id: 'notif', icon: '🔔', label: 'नोटिफिकेशन', bg: Color(0xFFFFE0DC), tag: 'अपडेट्स', note: 'लाइक्स, मैसेज, कमाई अपडेट्स और फॉलो रिक्वेस्ट की सभी सूचनाएं यहां आएंगी।'),
];

class SampleVideo {
  final String url;
  final String creator;
  final String caption;
  const SampleVideo({required this.url, required this.creator, required this.caption});
}

const List<SampleVideo> kSampleVideos = [
  SampleVideo(url: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4', creator: '@नेहा_क्रिएट्स', caption: 'शाम की सैर 🌸'),
  SampleVideo(url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4', creator: '@रवि_व्लॉग्स', caption: 'कैंपफायर वाइब्स 🔥'),
  SampleVideo(url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4', creator: '@अमन_एनिमेशन', caption: 'शॉर्ट फिल्म क्लिप 🎞️'),
];
