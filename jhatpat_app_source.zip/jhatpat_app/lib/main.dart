import 'package:flutter/material.dart';
import 'theme.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const JhatpatApp());
}

class JhatpatApp extends StatelessWidget {
  const JhatpatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'झटपट',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.theme,
      home: const HomeScreen(),
    );
  }
}
