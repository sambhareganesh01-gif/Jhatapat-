import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../models/feature.dart';
import '../theme.dart';

/// रील्स-स्टाइल वर्टिकल वीडियो फ़ीड — ऊपर/नीचे स्वाइप करके अगला वीडियो चलता है।
class VideoScreen extends StatelessWidget {
  const VideoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          children: [
            PageView.builder(
              scrollDirection: Axis.vertical,
              itemCount: kSampleVideos.length,
              itemBuilder: (context, index) => _ReelItem(video: kSampleVideos[index]),
            ),
            Positioned(
              top: 8,
              left: 8,
              child: GestureDetector(
                onTap: () => Navigator.of(context).maybePop(),
                child: Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.arrow_back, color: Colors.white, size: 18),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ReelItem extends StatefulWidget {
  final SampleVideo video;
  const _ReelItem({required this.video});

  @override
  State<_ReelItem> createState() => _ReelItemState();
}

class _ReelItemState extends State<_ReelItem> {
  late VideoPlayerController _controller;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.networkUrl(Uri.parse(widget.video.url))
      ..initialize().then((_) {
        if (mounted) setState(() {});
        _controller.setLooping(true);
        _controller.play();
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _controller.value.isPlaying ? _controller.pause() : _controller.play();
        });
      },
      child: Stack(
        fit: StackFit.expand,
        children: [
          _controller.value.isInitialized
              ? FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _controller.value.size.width,
                    height: _controller.value.size.height,
                    child: VideoPlayer(_controller),
                  ),
                )
              : const Center(child: CircularProgressIndicator(color: AppColors.marigold)),
          Positioned(
            left: 16,
            right: 70,
            bottom: 24,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.video.creator, style: AppTheme.body(size: 13, weight: FontWeight.w700, color: Colors.white)),
                const SizedBox(height: 3),
                Text(widget.video.caption, style: AppTheme.body(size: 12, color: Colors.white.withOpacity(0.9))),
              ],
            ),
          ),
          Positioned(
            right: 12,
            bottom: 24,
            child: Column(
              children: const [
                Icon(Icons.favorite, color: Colors.white, size: 26),
                SizedBox(height: 18),
                Icon(Icons.mode_comment, color: Colors.white, size: 24),
                SizedBox(height: 18),
                Icon(Icons.share, color: Colors.white, size: 24),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
