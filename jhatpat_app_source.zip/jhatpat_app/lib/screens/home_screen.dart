import 'package:flutter/material.dart';
import '../models/feature.dart';
import '../theme.dart';
import '../widgets/bottom_nav.dart';
import 'feature_screen.dart';
import 'video_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _activeNav = 'home';

  void _openFeature(String id) {
    if (id == 'video') {
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => const VideoScreen()));
      return;
    }
    final feature = kFeatures.firstWhere((f) => f.id == id, orElse: () => kFeatures.first);
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => FeatureScreen(feature: feature)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.paper,
      body: Column(
        children: [
          // Status-bar-safe header
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(20, 50, 20, 22),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [AppColors.ink, AppColors.inkSoft],
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 34,
                          height: 34,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            gradient: const LinearGradient(
                              colors: [AppColors.marigold, AppColors.marigoldDeep],
                            ),
                          ),
                          child: const Icon(Icons.bolt, color: AppColors.ink, size: 20),
                        ),
                        const SizedBox(width: 10),
                        Text('झटपट', style: AppTheme.display(size: 22, weight: FontWeight.w800, color: AppColors.paper)),
                      ],
                    ),
                    GestureDetector(
                      onTap: () => _openFeature('notif'),
                      child: Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.06),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.white.withOpacity(0.09)),
                        ),
                        child: Stack(
                          children: [
                            const Center(child: Icon(Icons.notifications, color: AppColors.paper, size: 18)),
                            Positioned(
                              top: 8,
                              right: 8,
                              child: Container(
                                width: 7,
                                height: 7,
                                decoration: const BoxDecoration(color: AppColors.coral, shape: BoxShape.circle),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text('नमस्ते, आज क्या करना है?', style: AppTheme.body(size: 12, color: AppColors.paper.withOpacity(0.55))),
                const SizedBox(height: 16),
                Container(
                  height: 42,
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.07),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.white.withOpacity(0.09)),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.search, size: 18, color: Colors.white.withOpacity(0.4)),
                      const SizedBox(width: 8),
                      Text('Search झटपट...', style: AppTheme.body(size: 13, color: Colors.white.withOpacity(0.4))),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Scrollable body
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 20),
              children: [
                // Stories
                SizedBox(
                  height: 78,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    children: const [
                      _Story(emoji: '➕', name: 'आप'),
                      _Story(emoji: '🧑', name: 'रवि'),
                      _Story(emoji: '👩', name: 'प्रिया'),
                      _Story(emoji: '🧑\u200d🦱', name: 'अमन'),
                      _Story(emoji: '👩\u200d🦰', name: 'नेहा'),
                    ],
                  ),
                ),
                const SizedBox(height: 20),

                // Earnings banner
                GestureDetector(
                  onTap: () => _openFeature('earnings'),
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      gradient: const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [AppColors.teal, Color(0xFF0891A6)],
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('आज की कमाई देखें', style: AppTheme.display(size: 17, color: Colors.white)),
                        const SizedBox(height: 4),
                        Text('रील्स और शॉप से ₹0.00 अब तक', style: AppTheme.body(size: 12, color: Colors.white.withOpacity(0.85))),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 22),

                Text('सभी फीचर्स', style: AppTheme.body(size: 11, weight: FontWeight.w800, color: AppColors.ink.withOpacity(0.4))),
                const SizedBox(height: 12),

                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: kFeatures.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 0.92,
                  ),
                  itemBuilder: (context, index) {
                    final f = kFeatures[index];
                    return GestureDetector(
                      onTap: () => _openFeature(f.id),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: AppColors.ink.withOpacity(0.06)),
                          boxShadow: [BoxShadow(color: AppColors.ink.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, 2))],
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: 46,
                              height: 46,
                              decoration: BoxDecoration(color: f.bg, borderRadius: BorderRadius.circular(14)),
                              child: Center(child: Text(f.icon, style: const TextStyle(fontSize: 21))),
                            ),
                            const SizedBox(height: 9),
                            Text(
                              f.label,
                              textAlign: TextAlign.center,
                              style: AppTheme.body(size: 11.5, weight: FontWeight.w700),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),

          JhatpatBottomNav(
            active: _activeNav,
            onTap: (id) {
              if (id == 'home') {
                setState(() => _activeNav = 'home');
              } else {
                setState(() => _activeNav = id);
                _openFeature(id);
              }
            },
            onFabTap: () => _openFeature('studio'),
          ),
        ],
      ),
    );
  }
}

class _Story extends StatelessWidget {
  final String emoji;
  final String name;
  const _Story({required this.emoji, required this.name});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 12),
      child: SizedBox(
        width: 58,
        child: Column(
          children: [
            Container(
              width: 54,
              height: 54,
              padding: const EdgeInsets.all(2.5),
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(colors: [AppColors.marigold, AppColors.coral]),
              ),
              child: Container(
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(colors: [Color(0xFFE8DFFF), Color(0xFFFFD9DD)]),
                ),
                child: Center(child: Text(emoji, style: const TextStyle(fontSize: 20))),
              ),
            ),
            const SizedBox(height: 6),
            Text(name, style: AppTheme.body(size: 10, weight: FontWeight.w600, color: AppColors.ink.withOpacity(0.6))),
          ],
        ),
      ),
    );
  }
}
