import 'package:flutter/material.dart';
import '../models/feature.dart';
import '../theme.dart';

/// सामान्य फीचर स्क्रीन — जब तक किसी फीचर की खुद की स्क्रीन नहीं बनी है
/// (जैसे वीडियो), तब तक यही टेम्प्लेट इस्तेमाल होता है।
class FeatureScreen extends StatelessWidget {
  final Feature feature;
  const FeatureScreen({super.key, required this.feature});

  Widget _mockLine(double widthFactor) {
    return FractionallySizedBox(
      widthFactor: widthFactor,
      alignment: Alignment.centerLeft,
      child: Container(
        height: 12,
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: AppColors.ink.withOpacity(0.08),
          borderRadius: BorderRadius.circular(6),
        ),
      ),
    );
  }

  Widget _mockCard(List<double> lines) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.ink.withOpacity(0.06)),
        boxShadow: [BoxShadow(color: AppColors.ink.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, 2))],
      ),
      child: Column(children: lines.map(_mockLine).toList()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.paper,
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(18, 56, 18, 18),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [AppColors.ink, AppColors.inkSoft],
              ),
            ),
            child: Row(
              children: [
                GestureDetector(
                  onTap: () => Navigator.of(context).maybePop(),
                  child: Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.white.withOpacity(0.09)),
                    ),
                    child: const Icon(Icons.arrow_back, color: AppColors.paper, size: 18),
                  ),
                ),
                const SizedBox(width: 12),
                Text(feature.label, style: AppTheme.display(size: 18, color: AppColors.paper)),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 22, 20, 40),
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5),
                  decoration: BoxDecoration(
                    color: AppColors.marigold.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(feature.tag, style: AppTheme.body(size: 11, weight: FontWeight.w700, color: const Color(0xFFB36A00))),
                ),
                const SizedBox(height: 14),
                _mockCard([0.7, 0.92, 0.55]),
                _mockCard([0.8, 0.4]),
                Text(feature.note, style: AppTheme.body(size: 12.5, color: AppColors.ink.withOpacity(0.5)).copyWith(height: 1.6)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
