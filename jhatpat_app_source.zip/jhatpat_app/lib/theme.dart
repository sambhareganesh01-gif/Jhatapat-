import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// झटपट का रंग पैलेट और टाइपोग्राफी — पूरे ऐप में यहीं से इस्तेमाल होगा।
class AppColors {
  static const ink = Color(0xFF1B1035);
  static const inkSoft = Color(0xFF2E2050);
  static const paper = Color(0xFFFFF8ED);
  static const marigold = Color(0xFFFFB800);
  static const marigoldDeep = Color(0xFFFF8A00);
  static const coral = Color(0xFFFF5D73);
  static const teal = Color(0xFF06B6A4);
  static const violet = Color(0xFF8B5CF6);
}

class AppTheme {
  static TextStyle display({double size = 20, FontWeight weight = FontWeight.w700, Color color = AppColors.ink}) {
    return GoogleFonts.baloo2(fontSize: size, fontWeight: weight, color: color);
  }

  static TextStyle body({double size = 13, FontWeight weight = FontWeight.w500, Color color = AppColors.ink}) {
    return GoogleFonts.notoSansDevanagari(fontSize: size, fontWeight: weight, color: color);
  }

  static ThemeData get theme {
    return ThemeData(
      scaffoldBackgroundColor: AppColors.paper,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.marigold,
        primary: AppColors.marigold,
        secondary: AppColors.coral,
      ),
      fontFamily: GoogleFonts.notoSansDevanagari().fontFamily,
      useMaterial3: true,
    );
  }
}
