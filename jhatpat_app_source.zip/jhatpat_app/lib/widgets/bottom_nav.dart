import 'package:flutter/material.dart';
import '../theme.dart';

class JhatpatBottomNav extends StatelessWidget {
  final String active; // 'home' | 'video' | 'chat' | 'profile'
  final void Function(String id) onTap;
  final VoidCallback onFabTap;

  const JhatpatBottomNav({
    super.key,
    required this.active,
    required this.onTap,
    required this.onFabTap,
  });

  Widget _item(String id, String icon, String label) {
    final isActive = active == id;
    return GestureDetector(
      onTap: () => onTap(id),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(icon, style: TextStyle(fontSize: 20, color: isActive ? AppColors.marigoldDeep : AppColors.ink.withOpacity(0.4))),
          const SizedBox(height: 4),
          Text(label, style: AppTheme.body(
            size: 9.5,
            weight: FontWeight.w700,
            color: isActive ? AppColors.marigoldDeep : AppColors.ink.withOpacity(0.4),
          )),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 76,
      padding: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: AppColors.paper.withOpacity(0.96),
        border: Border(top: BorderSide(color: AppColors.ink.withOpacity(0.08))),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _item('home', '🏠', 'होम'),
          _item('video', '🎬', 'वीडियो'),
          GestureDetector(
            onTap: onFabTap,
            child: Container(
              width: 52,
              height: 52,
              margin: const EdgeInsets.only(top: -26),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [AppColors.marigold, AppColors.coral],
                ),
                boxShadow: [BoxShadow(color: AppColors.coral.withOpacity(0.4), blurRadius: 18, offset: const Offset(0, 8))],
              ),
              child: const Icon(Icons.add, color: Colors.white, size: 26),
            ),
          ),
          _item('chat', '💬', 'चैट'),
          _item('profile', '👤', 'प्रोफाइल'),
        ],
      ),
    );
  }
}
